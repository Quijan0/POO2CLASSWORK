package co.edu.ue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.edu.ue.entity.User;
//import co.edu.ue.repository.UserData;
import co.edu.ue.service.IUserService;

@RestController
@RequestMapping(value = "api")
public class UserController {

	//UserData data = new UserData(); // Fuente de datos a traves de instanciacion


	//Inyeccion por interface
	@Autowired
	IUserService service;
	
	// Retorna todos los usuarios
	@GetMapping(value = "users")
	public List<User> getAllUsers() {
		return service.getAllUser();
	}
	
	@GetMapping(value = "users-id")
	public List<User> getAllUsersIdChallenge() {
		return service.getAllUserChangeId();
	}

	// Retorna un usuario por correo electronico
	@GetMapping(value = "user-email")
	public User getUserEmail(@RequestParam("email") String correo) {
		return service.getByMail(correo);
	}

	// Retorna por id
	@GetMapping(value = "user-id")
	public User getUserId(@RequestParam("id") Integer id) {
		return service.getById(id);
	}
	
	//Agregar un usuario
	@PostMapping(value = "user")
	public List<User> postUser(@RequestBody User user){
		return service.getSaveUser(user);
	}
	@DeleteMapping(value="user")
	public List<User> deleteUser(@RequestParam("id") Integer id){
		return service.deleteUserById(id);
	}
	
}
