package co.edu.ueservicio;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PrimerController {
	
	//EndPoint Welcome.
	@GetMapping(value="Welcome", produces = MediaType.APPLICATION_JSON_VALUE)
	public String bienvenida() {
		return "Bienvenido a SpringBoot";
	}
	
	
	// Recibir parametros en la peticion get
	@GetMapping(value="Welcome/{name}")
	public String bienvenidaPersonalizada(@PathVariable("name") String nombre ) {
		return "Bienvenido a SpringBoot "+nombre;
	}
	@RequestMapping(value="Welcomes",method = RequestMethod.GET)
	public String bienvenidaPersonalizada(@RequestParam("name") String nombre, @RequestParam("lastname")String apellidos) {
		return"Welcomes " + nombre+""+apellidos;
	}
	
}
