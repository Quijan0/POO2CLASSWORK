package co.edu.ue.service;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.edu.ue.entity.User;
import co.edu.ue.repository.UserData;

@Service
public class UserService implements IUserService{
	
	//Inyeccion por constructor
	/*
	 * Tipos de inyeccion: atributo o campo, metodo set, interface, constructor
	 **/
	
	@Value("${code}")
	float code;
	
	//private final int NUM_CODE = 100;
	public UserService(UserData data) {
		this.data = data;
	}
	
	private UserData data;
	
	@Override
	public List<User> getAllUser() {
		return data.getListUser();
	}

	@Override
	public List<User> getAllUserChangeId() {
		/*stream*/
		return data.getListUser().stream().map(
				//Casteo de tipos de datos numericos
				u->{
					short value =(short)(u.getId() * code);
					User user = new User(value,u.getName(),u.getLastName(),u.getMail());
					return user;
				}
				
				).collect(Collectors.toList());
	}

	@Override
	public User getByMail(String email) {
		return data.getUserByMail(email);
	}

	@Override
	public User getById(Integer id) {
		return data.getUserById(id);
	}

	@Override
	public List<User> getSaveUser(User user) {
		return data.postUser(user);
	}

	@Override
	public List<User> deleteUserById(Integer id) {
		return data.deleteUser(id);
	}

	
}
