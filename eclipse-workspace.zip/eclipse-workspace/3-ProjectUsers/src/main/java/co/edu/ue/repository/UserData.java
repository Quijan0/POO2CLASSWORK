package co.edu.ue.repository;

import org.springframework.stereotype.Repository;

import co.edu.ue.entity.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Repository
public class UserData { // Fuente de datos
	// 1.Declaracion de atributos

	List<User> listUsers; // Coleccion

	// 2. Constructor

	public UserData() {
		super();
		this.listUsersData();
	}

	public void listUsersData() {
		this.listUsers = new ArrayList<User>(Arrays.asList(
				new User(1, "SOFIA", "LATORRE", "SOFIA@GMAIL.COM"),
				new User(2, "ANDRES", "MARTINEZ", "ANDRES@GMAIL.COM"), 
				new User(3, "LUIS", "ACEVEDO", "AC@GMAIL.COM"),
				new User(4, "MIGUEL", "RODRIGUEZ", "RO@GMAIL.COM"), 
				new User(5, "SOILA", "LAURENT", "LA@GMAIL.COM")
				));
	}

	public List<User> getListUser() {
		return this.listUsers;
	}

	public User getUserByMail(String email) {
		for (User s : this.listUsers) {
			if (s.getMail().contains(email)) {
				return s;
			}
		}
		return null;
	}

	public User getUserById(Integer id) {
		return this.listUsers.stream().filter(i -> i.getId().equals(id)).findFirst().orElseThrow();
	}

	public List<User> postUser(User user) {
		boolean response = this.listUsers.add(user);
		if (response) {
			return this.listUsers;
		}
		return null;
	}

	public List<User> deleteUser(Integer id) {
		this.listUsers.removeIf(u -> u.getId().equals(id));
		return this.listUsers;
	}

}
/*
 * public User updateUser(Integer id, User newUser) { for (User user :
 * this.listUsers) { if (user.getId().equals(id)) {
 * user.setName(newUser.getName()); user.setLastName(newUser.getLastName());
 * user.setMail(newUser.getMail()); return user; } } return null; // Devuelve
 * null si el usuario no se encontró
 */
/*	public List<User> UpdateUser(User user) {
	for (User usera : this.listUsers) {
	if (user.getId().equals(1)) {
	user.setName("Andres");
			}
		}
		return null;
	}*/
