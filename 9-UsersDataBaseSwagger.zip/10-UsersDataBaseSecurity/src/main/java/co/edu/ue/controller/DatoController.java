package co.edu.ue.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.edu.ue.entity.Dato;
import co.edu.ue.service.IDatoService;
import java.util.List;

@RestController
public class DatoController {

	@Autowired
	IDatoService service;

	// ResponseEntity

	@PostMapping(value = "dato-sav", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Dato>> postDato(@RequestBody Dato dato) {
		List<Dato> listDato = service.addDato(dato);
		return new ResponseEntity<List<Dato>>(listDato, HttpStatus.CREATED);
	}

	@GetMapping(value = "dato-all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Dato>> getAllDato() {
		// Incluir en la cabecera la cantidad de registros
		List<Dato> listDato = service.ListAll();
		// 1.Instanciamos un objeto de tipo header para agreagar la informacion en la
		// cabecera
		HttpHeaders headers = new HttpHeaders();
		// 2.Agregamos la informacion con el medtodo add
		headers.add("cantDatos", String.valueOf(listDato.size()));
		headers.add("test", "valor");
		return new ResponseEntity<List<Dato>>(listDato, headers, HttpStatus.OK);
	}

	@PutMapping()
	public ResponseEntity<Dato> putDato(@RequestBody Dato dato) {
		return new ResponseEntity<Dato>(service.upDato(dato), HttpStatus.ACCEPTED);
	}

	@GetMapping(value = "dato-id")
	public ResponseEntity<Dato> getIdDato(@RequestParam("id") int id) {
		return new ResponseEntity<Dato>(service.findIdDato(id), HttpStatus.OK);
	}

	@GetMapping(value = "dato-email")
	public ResponseEntity<Dato> getEmailDato(@RequestParam("email") String mail) {
		return new ResponseEntity<Dato>(service.findEmailDato(mail), HttpStatus.OK);
	}

}
