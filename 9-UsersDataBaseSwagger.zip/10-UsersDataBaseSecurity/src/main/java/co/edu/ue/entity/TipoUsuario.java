package co.edu.ue.entity;
import jakarta.persistence.*;
import java.io.Serializable;


/**
 * The persistent class for the tipo_usuarios database table.
 * 
 */
@Entity
@Table(name="tipo_usuarios")
@NamedQuery(name="TipoUsuario.findAll", query="SELECT t FROM TipoUsuario t")
public class TipoUsuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="tip_id")
	private int tipId;

	@Column(name="tip_user")
	private String tipUser;

	public TipoUsuario() {
	}

	public int getTipId() {
		return this.tipId;
	}

	public void setTipId(int tipId) {
		this.tipId = tipId;
	}

	public String getTipUser() {
		return this.tipUser;
	}

	public void setTipUser(String tipUser) {
		this.tipUser = tipUser;
	}

}